# Script para ejecutar análisis de medicamentos
Set-Location "c:\Users\ianar\Documents\SIC Samsung\PanaRemedy"
& .\venv\Scripts\activate
Set-Location Proyecto
python aplicacion.py
Read-Host "Presiona Enter para continuar..."